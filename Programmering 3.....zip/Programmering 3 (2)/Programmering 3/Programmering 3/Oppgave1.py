from PIL import Image
import pilgram2
import os
from pathlib import Path

current_directory = Path.cwd()
dir_path = current_directory / "Bilder"


im = Image.open(os.path.join(dir_path, "Tree.jpg"))
pilgram2.toaster(im).save('Tree-Toaster.jpg')