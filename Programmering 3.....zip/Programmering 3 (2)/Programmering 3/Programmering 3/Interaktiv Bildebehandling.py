import os
from PIL import Image, ImageOps
import pilgram2
import random
from pathlib import Path

current_directory = Path.cwd()

folder_name = "Bilder"
subfolder_name = "Resultat"
dir_path = current_directory / folder_name
Resultat_dir_path = current_directory / subfolder_name
Rotation = 0
Randomnumber = 0
Filtr = 0
scale_factor = 0
Isedited = False
Hasended = False
Ischoosing = False

images = []
Filters = ["_1977", "aden", "ashby", "amaro", "brannan", "brooklyn", "charmes", "clarendon", "crema",
            "dogpatch", "earlybird", "gingham", "ginza", "hefe", "helena", "hudson", "inkwell", "juno",
              "kelvin", "lark", "lofi", "ludwig", "maven", "mayfair", "moon", "nashville", "perpetua", 
              "poprocket", "reyes", "rise", "sierra", "skyline", "slumber", "stinson", "sutro", "toaster",
                "valencia", "valden", "willow", "xpro2"]

for (dir_path, dir_names, file_names) in os.walk(dir_path):
    images.extend(file_names)

print("Velg bilde")
for idx, image in enumerate(images, start=1):
    print(f"{idx}. {image}")

valg = int(input("Skriv her: "))
if valg < idx + 1:
    ChosenImage = images[valg - 1]

while not Hasended:
    print("-----------------------")
    print("What do you want to do with the image?")
    print("1. Scale")
    print("2. Add-filter")
    print("3. Rotate")
    print("4. Export")
    Misation = int(input("Skriv her: "))
    
    if Misation == 1:
        Isedited = True
        im = Image.open(os.path.join(dir_path, ChosenImage))
        scale_factor = float(input("Enter the scale factor (e.g., 0.5 for 50% reduction): "))
        width, height = im.size
        new_size = (int(width * scale_factor), int(height * scale_factor))
        im = im.resize(new_size)
        base_name, ext = os.path.splitext(ChosenImage)
        new_filename = f"{base_name}-Scaled.jpg"
        im.save(os.path.join(Resultat_dir_path, new_filename))
        
        print("Operation completed. Going back to Export menu.")

    elif Misation == 2:
        print("-----------------------")
        print("What filter?")
        print("1. Instagram")
        print("2. Black&White")
        print("3. Random")
        print("4. Polaroid")
        Filtr = int(input("Skriv her: "))
        Isedited = True

        base_name, ext = os.path.splitext(ChosenImage)

        if Filtr == 4:
            input_image_path = current_directory / "Bilder" / ChosenImage
            photo_frame_path = current_directory / "Polaroid-Ref.png"

            photo = Image.open(input_image_path)
    
            photo = photo.rotate(Rotation)

            frame = Image.open(photo_frame_path)

            cropped_photo = ImageOps.fit(photo, (min(photo.size), min(photo.size)))
            scaled_photo = cropped_photo.resize((760, 760))

            polaroid = Image.new("RGB", frame.size, (255, 255, 255))
            polaroid.paste(scaled_photo, (64, 64))
            polaroid.paste(frame, (0, 0), frame)

            id = random.randint(0, 243543)
            new_filename = f"{base_name}-Result{str(id)}.png"
            polaroid.save(os.path.join(Resultat_dir_path, new_filename))
            print("Operation completed. Going back to Export menu.")
           

    elif Misation == 3:
        im = Image.open(os.path.join(dir_path, ChosenImage))
        Rotation = int(input("How many degrees do you want to rotate the image? "))
        im = im.rotate(Rotation)
        base_name, ext = os.path.splitext(ChosenImage)
        new_filename = f"{base_name}-Rotated.jpg"
        im.save(os.path.join(Resultat_dir_path, new_filename))
        Isedited = True
        print("Operation completed. Going back to Export menu.")

    elif Misation == 4:
        if Isedited:
            im = Image.open(os.path.join(dir_path, ChosenImage))
            width, height = im.size
            new_size = (int(width * scale_factor), int(height * scale_factor))
            im = im.resize(new_size)

            base_name, ext = os.path.splitext(ChosenImage)

            if Filtr == 4:
                input_image_path = current_directory / "Bilder" / ChosenImage
                photo_frame_path = current_directory / "Polaroid-Ref.png"

                photo = Image.open(input_image_path)
                frame = Image.open(photo_frame_path)

                cropped_photo = ImageOps.fit(photo, (min(photo.size), min(photo.size)))
                scaled_photo = cropped_photo.resize((760, 760))

                polaroid = Image.new("RGB", frame.size, (255, 255, 255))
                polaroid.paste(scaled_photo, (64, 64))
                polaroid.paste(frame, (0, 0), frame)

                id = random.randint(0, 243543)
                new_filename = f"{base_name}-Result{str(id)}.png"
                polaroid.save(os.path.join(Resultat_dir_path, new_filename))
                print("Image exported successfully.")
                Hasended = True
        else:
            im = Image.open(os.path.join(dir_path, ChosenImage))
            base_name, ext = os.path.splitext(ChosenImage)
            new_filename = f"{base_name}.jpg"
            im.save(os.path.join(Resultat_dir_path, new_filename))
            print("Original image exported successfully.")
            Hasended = True

    else:
        print("Invalid option. Please choose a valid operation.")
