from PIL import Image, ImageOps
from pathlib import Path

current_directory = Path.cwd()

input_image_path = current_directory / "Bilder/Tree.jpg"
photo_frame_path = current_directory / "Polaroid-Ref.png"

photo = Image.open(input_image_path)
frame = Image.open(photo_frame_path)


cropped_photo = ImageOps.fit(photo, (min(photo.size), min(photo.size)))


scaled_photo = cropped_photo.resize((760, 760))


polaroid = Image.new("RGB", frame.size, (255, 255, 255))
polaroid.paste(scaled_photo, (64, 64))


polaroid.paste(frame, (0, 0), frame)


output_path = current_directory / "Polaroid-img.png"
polaroid.save(output_path)