from PIL import Image
import os
from pathlib import Path

Size = int(input("What pixel size?: "))

def pixelate_image(input_path, output_path, pixel_size=10):
   
    im = Image.open(input_path)

    

   
    width, height = im.size
    new_width = width // pixel_size
    new_height = height // pixel_size

    
    pixelated_im = im.resize((new_width, new_height), resample=Image.NEAREST)

    
    pixelated_im = pixelated_im.resize((width, height), resample=Image.NEAREST)

    
    pixelated_im.save(output_path)


current_directory = Path.cwd()
dir_path = current_directory / "Bilder"

input_image_path = os.path.join(dir_path, "Tree.jpg")
output_image_path = 'Tree-Pixelated.jpg'

pixelate_image(input_image_path, output_image_path, pixel_size=Size)
