from PIL import Image
import pilgram2
import os
from pathlib import Path

def resize_and_apply_filter(input_path, output_path, target_width=1920, target_height=1080):
    
    im = Image.open(input_path)

    
    resized_im = im.resize((target_width, target_height))

   
    filtered_im = pilgram2.toaster(resized_im)

   
    filtered_im.save(output_path)


current_directory = Path.cwd()
dir_path = current_directory / "Bilder"

input_image_path = os.path.join(dir_path, "Tree.jpg")
output_image_path = 'Tree-Toaster-Resized.jpg'

resize_and_apply_filter(input_image_path, output_image_path)
