Tall1 = int(input("Skriv inn ett tall: "))
Tall2 = int(input("Skriv inn ett til tall: "))


def Summer(a, b):
    return a + b

print("Tallet ditt er: " + str(Summer(Tall1, Tall2)))