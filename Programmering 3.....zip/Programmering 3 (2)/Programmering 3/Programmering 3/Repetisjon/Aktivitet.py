import math


i = 0



for i in range(11):

    print(i ** i)

Lisl = [2, 5, 63, 9]
i = 0
NewLisl = []

for i in range(len(Lisl)):
    NewLisl.append(min(Lisl))
    Lisl.remove(min(Lisl))
print(NewLisl)

liste = [2, 2, 5, 6, 8, 8]

print(list(set(liste)))

tekst2 = ""
Tekst = input("Hva ord skal jeg skrive baklengs: ")
tekst2 += Tekst[::-1]
if tekst2 == Tekst:
    print("Dette er et palidrom")
else:
    print("Dette er ikke et palidrom")

print(tekst2)


g = 0


def Average(Rndlist):
    numresult = 0
    for g in range(len(Rndlist)):
        numresult += Rndlist[g]
    print(numresult / len(Rndlist))



Average([24, 3, 6, 4, 9, 2])




