Loops = int(input("Hvor mange ganger skal løkken kjøre?: "))
i = 0

while i < Loops: 
    i += 2
    print(i)
