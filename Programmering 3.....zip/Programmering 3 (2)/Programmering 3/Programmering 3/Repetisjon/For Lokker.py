i = 0
Max_Value = int(input("Hvor mange ganger?: "))
g = 0

for i in range(Max_Value):
    print(i + g)
    g += i

