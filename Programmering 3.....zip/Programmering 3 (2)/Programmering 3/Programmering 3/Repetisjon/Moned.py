MånedFødt = input("I hvilket måned ble du født?: ")
Måneder = ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"]
i = 0
for i in range(len(Måneder)):
    if MånedFødt == Måneder[i]:
        print("Du er født i " + Måneder[i])
