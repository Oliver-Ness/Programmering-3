i = 1

for i in range(11):
    print(i)
    
g = 0
result = 0

lenght = int(input("Hvor mange ganger?: "))

for g in range(lenght):

    result += g
    print(result)
    