
import random
Lengde = int(input("Hva er lengden?: "))
while Lengde > 0:
    print("Lengden er: " + str(Lengde))
    print("----------------------------------")
    Menge_Terninger = int(input("Hvor mange terninger?: "))

    i = 0
    resultat = 0
    Tilfelle = 0

    def Kast_Terning():
        return random.randint(1, 6)

    while Menge_Terninger > 0:
        Menge_Terninger -= 1
        Tilfelle = Kast_Terning()
        resultat += Tilfelle
        
    Lengde -= resultat
    print("Resultatet ble: " + str(resultat))
    

