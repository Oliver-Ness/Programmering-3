import random

Tall = []
Tall_Len = int(input("Lengde av sorterte tall: "))
Sortert_tall = []


while Tall_Len > 0:
    Tall_Len -= 1
    Tall.append(int(random.randint(0, 1000)))
    print(Tall)

max_val = len(Tall)
while max_val > 0:
    Sortert_tall.append(min(Tall))
    Tall.remove(min(Tall))
    max_val -= 1
    print(Sortert_tall)
